<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\UserController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('registration', [UserController::class, 'registration'])->name('registration');
Route::get('login', [UserController::class, 'index'])->name('login');

Route::get('dashboard', [UserController::class, 'dashboard']);
Route::get('logout', [UserController::class, 'logout'])->name('logout');
Route::get('/fetchall', [UserController::class, 'fetchAll'])->name('fetchAll');
Route::delete('/delete', [UserController::class, 'delete'])->name('delete');
Route::get('/edit', [UserController::class, 'edit'])->name('edit');
Route::get('/view', [UserController::class, 'view'])->name('view');
Route::post('/update', [UserController::class, 'update'])->name('update');
Route::get('/', function () {
    return view('welcome');
});
