<?php
namespace App\Http\Controllers\Api;
use Illuminate\Http\Request; 
use App\Http\Controllers\Controller; 
use App\Models\User;
use Illuminate\Support\Facades\Auth; 
use Validator;
use Session;
class UserController extends Controller 
{
public $successStatus = 200;
/** 
     * login api 
     * 
     * @return \Illuminate\Http\Response 
     */ 

    public function index()
    {
        return view('login');
    }
    public function registration()
    {
        return view('register');
    }
    public function login(){ 
        if(Auth::attempt(['email' => request('email'), 'password' => request('password')])){ 
            $user = Auth::user(); 
            $success['token'] =  $user->createToken('MyApp')->accessToken; 
           // return response()->json(['response'=>['code'=>'200','message'=>'login successfull']]);
           return redirect()->intended('dashboard')->withSuccess('You have Successfully logged in');
        } 
        else{ 
            return response()->json(['error'=>'Unauthorised'], 401); 
        } 
    }

    public function dashboard()
    {
        
            return view('dashboard');
          
    }
/** 
     * Register api 
     * 
     * @return \Illuminate\Http\Response 
     */ 
    public function register(Request $request) 
    { 
        $validator = Validator::make($request->all(), [ 
            'name' => 'required', 
            'email' => 'required|email', 
            'password' => 'required', 
           
        ]);
        $request->validate([
            'image' => 'required|image|mimes:jpeg,png,jpg|max:500',
        ]);
   if ($validator->fails()) { 
            return response()->json(['error'=>$validator->errors()], 401);            
        } 
        $image=$request->image;
        $imageName = time().'.'.$image->extension();  
     
        $image->move(public_path('image'), $imageName);
        $input = $request->all(); 
        $input['image'] =$imageName; 
        $input['password'] = bcrypt($input['password']); 
        $user = User::create($input); 
        $success['token'] =  $user->createToken('MyApp')->accessToken; 
        $success['name'] =  $user->name;
       // return response()->json(['response'=>['code'=>'200','message'=>'registration successfull']]);
         
        return redirect("login")->withSuccess('Great! please login.');
    }
/** 
     * details api 
     * 
     * @return \Illuminate\Http\Response 
     */ 


    public function details() 
    { 
        $user = Auth::user(); 
        return response()->json(['success' => $user], $this-> successStatus); 
    } 
	public function fetchAll() {
		$Users = User::all();
		$output = '';
		if ($Users->count() > 0) {
			$output .= '<table class="table table-striped table-sm text-center align-middle">
            <thead>
              <tr>
                <th>ID</th>
                <th>profile</th>
                <th>Name</th>
              
                <th>E-mail</th>
                
                
                <th>Action</th>
              </tr>
            </thead>
            <tbody>';
			foreach ($Users as $User) {
				$output .= '<tr>
                <td>' . $User->id . '</td>
                
                <td><img src="image/'.$User->image.'" width="50" class="img-thumbnail rounded-circle"></td>
                <td>' . $User->name .  '</td>
                <td>' . $User->email . '</td>
               
                
                <td>
                  <a href="#" id="' . $User->id . '" class="text-success mx-1 editIcon" data-bs-toggle="modal" data-bs-target="#editUserModal"><i class="bi-pencil-square h4"></i></a>
                 
                  <a href="#" id="' . $User->id . '" class="text-danger mx-1 deleteIcon"><i class="bi-trash h4"></i></a>
                  <a href="#" id="' . $User->id . '" class="text-info mx-1 viewIcon" data-bs-toggle="modal" data-bs-target="#viewUserModal"><i class="bi-eye-fill h4"></i></a>
                </td>
              </tr>';
			}
			$output .= '</tbody></table>';
			echo $output;
		} else {
			echo '<h1 class="text-center text-secondary my-5">No record present in the database!</h1>';
		}
	}

	
	

	// handle edit an User
	public function edit(Request $request) {
		$id = $request->id;
		$User = User::find($id);
        
		return response()->json($User);
	}
// handle view user 
public function view(Request $request) {
    $id = $request->id;
    $User = User::find($id);
   
    return response()->json($User);
}
	// handle update an User
	public function update(Request $request) {
		$fileName = '';
		$User = User::find($request->User_id);

		$UserData = ['name' => $request->name,
        
         'email' => $request->email
         
        ];

		$User->update($UserData);
		return response()->json([
			'status' => 200,
		]);
	}

	// handle delete an User
	public function delete(Request $request) {
		$id = $request->id;
		$User = User::find($id);
        User::destroy($id);
		
	}

    public function logout() {
        Session::flush();
        Auth::logout();
  
        return Redirect('login');
    }
    
}